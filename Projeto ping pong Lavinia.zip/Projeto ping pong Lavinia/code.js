var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["715a3124-bade-49bb-9664-fec309a9fc69","06a68c1b-606b-46da-b388-81d233916b97","8a49b94d-80fb-47e2-95c1-b751d0224d7b","7664bbbf-77b9-4403-9bcf-13d90c306229"],"propsByKey":{"715a3124-bade-49bb-9664-fec309a9fc69":{"name":"tartaruga-computer","sourceUrl":"assets/api/v1/animation-library/gamelab/6ouXq4uNHs.GatlrdN52bUa6fxcByx9R/category_animals/cuteanimals_tortoise.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"6ouXq4uNHs.GatlrdN52bUa6fxcByx9R","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/6ouXq4uNHs.GatlrdN52bUa6fxcByx9R/category_animals/cuteanimals_tortoise.png"},"06a68c1b-606b-46da-b388-81d233916b97":{"name":"golfinho-jogador","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"VXuD7cppARrYGLQqge96JvzFndls_Oh.","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/06a68c1b-606b-46da-b388-81d233916b97.png"},"8a49b94d-80fb-47e2-95c1-b751d0224d7b":{"name":"bola","sourceUrl":null,"frameSize":{"x":86,"y":86},"frameCount":1,"looping":true,"frameDelay":12,"version":"rG992Cne2X6P4zsaKrJM0iZnNRd2UW4D","categories":["board_games_and_cards"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":86,"y":86},"rootRelativePath":"assets/8a49b94d-80fb-47e2-95c1-b751d0224d7b.png"},"7664bbbf-77b9-4403-9bcf-13d90c306229":{"name":"background","sourceUrl":"assets/api/v1/animation-library/gamelab/b.wUIlJjGpUDp5hPJOOrJBX9HqHOOATt/category_backgrounds/background_underwater_05.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"b.wUIlJjGpUDp5hPJOOrJBX9HqHOOATt","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/b.wUIlJjGpUDp5hPJOOrJBX9HqHOOATt/category_backgrounds/background_underwater_05.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var fundo = createSprite(200, 200);
fundo.setAnimation("background");

var playerPaddle= createSprite(390,200,10,100);
playerPaddle.setAnimation("golfinho-jogador");
playerPaddle.scale = 0.3;

var computerPaddle= createSprite(10,200,10,100);
computerPaddle.setAnimation("tartaruga-computer");
computerPaddle.scale = 0.3;

var ball= createSprite(200,200,10,10);
ball.setAnimation("bola");
ball.scale = 0.3;


function draw() {
  background("white");
  if(ball.isTouching(playerPaddle) || ball.isTouching(computerPaddle))
  {
    playSound("assets/hit.mp3");
  }
  
  
  if (keyDown("up")) {
    playerPaddle.y=playerPaddle.y-10;
  }
  
  if (keyDown("down")) {
    playerPaddle.y=playerPaddle.y+10;
  }
  
  if(keyDown("space"))
  {
     ball.velocityX=2;
     ball.velocityY=3;
  }
  
  computerPaddle.y=ball.y;

  drawnet();
  
 
    
  createEdgeSprites();
  ball.bounceOff(topEdge);
  ball.bounceOff(bottomEdge);
  ball.bounceOff(computerPaddle);
  ball.bounceOff(playerPaddle);
  drawSprites();
  
}



function drawnet()
{  
  for(var num=0;num<400;num=num+20)
  {
    line(200,num,200,num+10);
  }
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
